# exercicio 01 da aula 02
import math
import numpy as np
import collections
#funcao para calcular distancia
def calcularDistancia(p1,p2):
    """
    formula para calcular a distancia entre 2 pontos
    entradas:
    p1 - primeiro ponto: array numpy contento as coordenadas do primeiro ponto
    p2 - segundo ponto : array numpy contento as coordenadas do segundo ponto

    saida:
     distancia euclidiana dos pontos
    """

    distancia = np.linalg.norm(p1 - p2)
    # retornando o valor da distancia
    return distancia

def buscaPontoProximo (listaDePontos, pontoAlvo):

    distanciaPonto = None
    distanciaPontoProximo = float('inf')
    print(distanciaPontoProximo)

    for ponto in listaDePontos:
        distanciaAtual = calcularDistancia(pontoAlvo, ponto)

        if distanciaAtual < distanciaPontoProximo:
            distanciaPontoProximo = distanciaAtual
            distanciaPonto = ponto

    return distanciaPonto



def contadorDeStrigs(listaStrings):
    '''
    :param listaStrings: recebe uma lista de palavras
    :return: retorna as palavras e a quantidade que cada uma na lista
    '''
    contadorString = {}
    for palavra in set(listaStrings):
        cont = listaStrings.count(palavra)
        contadorString[palavra] = cont
    return contadorString



def analiseDeProximidade(listaPalavra, palavra,limiarDeAnalise):
    '''

    :param listaPalavra: lista de palavras para fazer a busca
    :param palavra: palavras de busca na lista
    :param limiarDeAnalise: numero de proximidade
    :return: lista com as palavas de proximidade
    '''

    #cria um array numpy ndarray
    array = np.array(listaPalavra)
    # retorna o(s) indice(s) da palavra de busca
    a = np.where(array == palavra)
    #lista com o(s) indice(s)
    listaindices = a[0]
    #criacao da lista de retonro
    listaDeretorno = []
    for indice in listaindices:
        # limita o indice do inicio da lista
        if (indice - limiarDeAnalise<0):
            inicio = 0
        else:
            inicio = indice - limiarDeAnalise

        # limita o indice de fim da lista
        if (indice + limiarDeAnalise + 1 > len(listaPalavra)):
            listaTemporaria = listaPalavra[inicio:]
        else:
            fim = indice + limiarDeAnalise + 1
            listaTemporaria = listaPalavra[inicio:fim]
        #adicionando elemento a lista de retorno
        listaDeretorno = listaDeretorno + listaTemporaria
        #removendo palavras de busca
        listaDeretorno.remove(palavra)
    return listaDeretorno


def retornalistarepetidos(lista):
    """
    função que retorna itens repetidos de um lista
    entradas:
    lista: array numpy contento as coordenadas do primeiro ponto

    saida:
     lista com os valores repetidos na lista informada
    """
    y = collections.Counter(lista)
    return [i for i in y if y[i] > 1]

def ordenalista(lista, crescente):
    """
    função ordenar uma lista baseada na quantidade de elementos de cada string

    entrada:
    lista: lista a ser ordenada
    crescente: tipo booleano ser ordenava a lista crescente

    saida:
    retorna uma lista ordenada ou não
    """
    for i in range(len(lista) - 1, 0, -1):
        for indice in range(i):
            if len(lista[indice]) > len(lista[indice + 1]):
                aux = lista[indice]
                lista[indice] = lista[indice + 1]
                lista[indice + 1] = aux

    return sorted(lista, key=len, reverse=crescente)