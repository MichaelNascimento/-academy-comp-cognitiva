import numpy as np

from src.gen_function import buscaPontoProximo
import argparse

def main():
    ap = argparse.ArgumentParser()

    ap.add_argument('-p1', '--lista_pontos',
                    default=np.array([[5.9,6.1],[6.4,2.2],[7.1,5.2],[12.1,9.7]]),
                    help='lista com os ponto')

    ap.add_argument('-p2', '--pontoDeAnalise',
                    default=np.array([6.7,5.2]),
                    help='ponto para fazer a analise')

    args = vars(ap.parse_args())

    p1 = args['lista_pontos']
    p2 = args['pontoDeAnalise']

    resultado = buscaPontoProximo(p1, p2)

    print(resultado)

if __name__ == '__main__':
    main()