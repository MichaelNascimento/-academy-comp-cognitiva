from src.gen_function import retornalistarepetidos
import argparse
import numpy as np

def main():
    ap = argparse.ArgumentParser()

    ap.add_argument('-lista', '--listadeentrada',
                    default=np.array(['ovo', 'teste', 'arvore', 'Mascara', 'ovo', 'Mascara']),
                    help='Lista a ser pesquisada')

    args = vars(ap.parse_args())

    listastring = args['listadeentrada']

    itensRepetidos = retornalistarepetidos(listastring)
    print(itensRepetidos)

if __name__ == '__main__':
    main()
