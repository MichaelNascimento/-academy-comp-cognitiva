import numpy as np
import argparse

def Create_ROI(_Matrix,_ROI_Center_Cordinates,_ROIsize):
    '''

    :param _Matrix: The Matrix to be processed
    :param _ROI_Center_Cordinates: Center points coordinates for ROI
    :param _ROIsize: Size of ROI
    :return: A matrix resulting
    '''
    radius = int(_ROIsize/2)
    ROI_matrix = np.zeros((_ROIsize, _ROIsize), np.uint8)
    i=0
    j=0

    for x in range(_ROI_Center_Cordinates[0] - radius,_ROI_Center_Cordinates[0] + radius + 1):
        for y in range(_ROI_Center_Cordinates[1] - radius, _ROI_Center_Cordinates[1] + radius + 1):
            #Check Corners
            if(x > _Matrix.shape[0] or x < 0):
                continue
            if (y > _Matrix.shape[1] or y < 0):
                continue
            ROI_matrix[i][j] = _Matrix[x][y]
            j+=1
        i+=1
        j=0

    return ROI_matrix

def Create_Multiples_ROI(_Matrix,_ROI_Center_Cordinates_list,_ROIsize_list):
    '''

    :param _Matrix: The Matrix to be processed
    :param _ROI_Center_Cordinates_list: List with center points of coordinates for ROIs
    :param _ROIsize_list:
    :return: A list of matrix resulting
    '''
    if(len(_ROI_Center_Cordinates_list)!=len(_ROIsize_list)):
        raise ValueError('_ROI_Center_Cordinates_list and _ROIsize_list has different sizes ')

    ROI_list = []
    for i in range(len(_ROI_Center_Cordinates_list)):
        ROI_list.append(Create_ROI(_Matrix, _ROI_Center_Cordinates_list[i], _ROIsize_list[i]))

    return ROI_list

def main():
    ap = argparse.ArgumentParser()

    ap.add_argument('-mtxsz', '--matrixsize',
                    default=[512,512],
                    help='Matrix size: Represents the size of matrix will be processed')

    ap.add_argument('-single', '--single',
                    default=0,
                    help='Function type: Single ROI(0), List of ROI(1)')

    ap.add_argument('-roictr', '--roicenter',
                    default=[128,128],
                    help='ROI center coordinates: Must be simple [x,y] if single ROI or a list of coordinates if multiples')

    ap.add_argument('-roisz', '--roisize',
                    default=15,
                    help='ROI size: Must be a integer if single ROI or a list of integers if multiples ROI')


    args = vars(ap.parse_args())
    sizeMatrix = args['matrixsize']
    typeFunction = args['single']
    RoiCenter = args['roicenter']
    RoiSize = args['roisize']

    matrix = np.ones(sizeMatrix, np.uint8)

    if(typeFunction == 0):
       result = Create_ROI(matrix, RoiCenter, RoiSize)
    else:
        result = Create_Multiples_ROI(matrix, RoiCenter, RoiSize)

    print(result)



if __name__ == '__main__':
    main()
    #result = Create_ROI(IMG, ROICenterCordinates, size_ROI)
    #result = Create_Multiples_ROI(IMG,roilisttest,roilistsizetest)
    #print(result)




