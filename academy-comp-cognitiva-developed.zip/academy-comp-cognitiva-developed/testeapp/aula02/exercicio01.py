import numpy as np

from src.gen_function import calcularDistancia
import argparse

def main():
    ap = argparse.ArgumentParser()

    ap.add_argument('-p1', '--ponto_1',
                    default=np.array([5,6]),
                    help='primeiro ponto')

    ap.add_argument('-p2', '--ponto_2',
                    default=np.array([15,12]),
                    help='segundo ponto')

    args = vars(ap.parse_args())

    p1 = args['ponto_1']
    p2 = args['ponto_2']

    resultado = calcularDistancia(p1, p2)

    print(resultado)

if __name__ == '__main__':
    main()